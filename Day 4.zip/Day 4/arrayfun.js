// 0   1  2  3  4   5
a=[12,34,45,415,676,78]
result= a.splice(2,0,90,200)// index,delcount,data1,data2...
console.log('the result',result)
console.log('the arr is',a)
