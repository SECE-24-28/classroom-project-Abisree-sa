let a=10
let b="10"
console.log(a==b)
console.log(a===b)


let c=9
let d=8
let v=45
console.log(c>d && c<45)
console.log(d==56)
console.log(!(c>d && c<45))

