var a=90
if(a<100)
a=9;
console.log(a);