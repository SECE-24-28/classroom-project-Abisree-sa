/*
no argument but return
function add()
{
    console.log("hello Moto")
    return 10
}
let d=add()
console.log("ans",d )*/

/*
argument and return  
function add(a,b)
{
    c=a+b
    console.log("hello Moto")
    return c
}
let d=add(12,13)
console.log("ans",d ) */

/*
no argument no return
function add()
{
    console.log("hello Moto")

}
add()
console.log("shivani")*/

/*argument but no return

function add(a,b)
{
    c=a+b
    console.log("hello Moto")
}
add(12,13)
console.log("ans") */