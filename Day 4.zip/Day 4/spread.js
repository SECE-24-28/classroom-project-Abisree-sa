var person=
{
    name:"shiva",
    dept:"it",
    mobile:12345
}
var address=
{
    city:"tirunelveli",
    state:"tamilnadu"
}
// var info={...person,...address}
// console.log(info)
//console.log(name)
const {name,mobile}=person
console.log(name,"........",mobile)
console.log(person)