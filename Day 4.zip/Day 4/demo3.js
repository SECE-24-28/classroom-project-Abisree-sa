let a="aarthi"
let b=90
let c=90.8765
let notdata=null
let r
let isvalid=true
console.log(a)
console.log(c)
console.log(r)
console.log(notdata)
