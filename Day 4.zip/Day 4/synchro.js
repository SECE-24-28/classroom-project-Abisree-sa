console.log("print1")
console.log("print2")
console.log("print3")
//printing one after the other by default with synchronisation


//asynchronisation

