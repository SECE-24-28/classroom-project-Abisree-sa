a=[12,13,14]
for(ar of a)
console.log(ar)
console.log(a)