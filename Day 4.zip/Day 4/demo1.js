let a=5;
if(a<15)
{
     let a=90;
     console.log (a)
}
console.log(a);

const o=9;
if(o<90)
{
console.log(o)
}
console.log(o)